<?php
if (isset($_POST['envoyer']))
 {
    # code...
    if (isset($_POST['user_nom']) AND isset($_POST['user_prenom']) AND isset($_POST['user_dateheure']) AND isset($_POST['user_destination']))
     {
        # code...
        if (!empty($_POST['user_nom']) AND !empty($_POST['user_prenom']) AND !empty($_POST['user_dateheure']) AND !empty($_POST['user_destination']))
         {
            # code...
            $nom=htmlspecialchars($_POST['user_nom']);
            $prenom=htmlspecialchars($_POST['user_prenom']);
            $dateheure=htmlspecialchars($_POST['user_dateheure']);
            $gestionaire=htmlspecialchars($_POST['user_gestionaire']);
          
        }
    }
}
echo"  <h2>merci pour votre reservation </h2>"
?>